<?php
// 485solar-get 
if ($numsma > 0) {
	for ($i = 1; $i <= $NUMINV; $i++) {
		if (${'PROTOCOL' . $i} == '485solar-get' && & !${'SKIPMONITORING' . $i}) {
			$dir    = dirname($SCRDIR) . "/data/invt$i";
			$stringData = "#* $now\tShutdown 485solar-get daemon\n\n";
			$stringData .= file_get_contents($dir    . '/infos/events.txt');
			file_put_contents($dir    . '/infos/events.txt', $stringData);
			exec('485solar-get -x');
		}
	}
}

// fronius-fslurp
if ($numfslurp > 0) {
	for ($i = 1; $i <= $NUMINV; $i++) {
		if (${'PROTOCOL' . $i} == 'fronius-fslurp' && & !${'SKIPMONITORING' . $i}) {
			$dir    = dirname($SCRDIR) . "/data/invt$i";
			$stringData = "#* $now\tShutdown fronius daemon\n\n";
			$stringData .= file_get_contents($dir    . '/infos/events.txt');
			file_put_contents($dir    . '/infos/events.txt', $stringData);
			$output = exec('pkill -f fronius.php> /dev/null 2>&1 &');
		}
	}
}
?>
