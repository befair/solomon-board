<?php
if(!defined('checkaccess')){die('Direct access not permitted');}
// Info text file on daily start-up
$CMD_INFO = "aurora -a ${'ADR'.$invt_num} ${'COMOPTION'.$invt_num} -p -n -f -g -m -v ${'PORT'.$invt_num}";
// Sync command on daily start-up
$CMD_SYNC ="aurora -a ${'ADR'.$invt_num} ${'COMOPTION'.$invt_num} -L5 ${'PORT'.$invt_num}"; //if drift >5sec from computer
?>
