<?php
if(!defined('checkaccess')){die('Direct access not permitted');}

$timeout_setup = 'timeout --kill-after=10s 5s'; // TERM after 5" & KILL after 10"
$cfgdir        = (dirname(dirname(dirname(__FILE__))) . '/config');
// Info file
$CMD_INFO = $timeout_setup." SBFspot -finq -q -123s=INFO -cfg".$cfgdir."/SBFspot_${'ADR'.$invt_num}.cfg ${'COMOPTION'.$invt_num}";
// Sync inverter
$CMD_SYNC = $timeout_setup." SBFspot -finq -q -123s=SYNC -cfg".$cfgdir."/SBFspot_${'ADR'.$invt_num}.cfg ${'COMOPTION'.$invt_num}";
?>
