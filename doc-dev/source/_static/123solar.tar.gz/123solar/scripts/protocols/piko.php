<?php
if(!defined('checkaccess')){die('Direct access not permitted');}
// For Piko stats http://sourceforge.net/projects/piko/
// With the help of Frank Ulbrich 

if ($DEBUG != 1) {
    $CMD_POOLING = "piko --host=192.168.1.10 -s -p -t -i -d";
} else {
    $CMD_POOLING = "piko --host=192.168.1.10 -s -p -t -i -d";
}
$datareturn = exec($CMD_POOLING);

$datareturn = " 
Inverter Status : 3 (Running)
Total energy : 801296 Wh
Today energy : 4841 Wh
DC Power : 2613 W
AC Power : 2414 W
Efficiency : 92.4%
DC String 1 : 640.4 V 3.24 A 2075 W T=a660 (41.21 C) S=4009
DC String 2 : 599.6 V 0.89 A 538 W T=a680 (41.14 C) S=c00a
DC String 3 : 0.0 V 0.00 A 0 W T=a660 (41.21 C) S=0003
AC Phase 1 : 234.8 V 3.45 A 791 W T=9a20 (48.21 C)
AC Phase 2 : 235.3 V 3.43 A 792 W T=9a20 (48.21 C)
AC Phase 3 : 241.6 V 3.54 A 831 W T=9a20 (48.21 C)
AC Status : 28 (001c ---L123)";

$datareturn_pieces = explode("\n", $datareturn);

print_r($datareturn_pieces);

$array = preg_split('/[[:space:]]+/', $datareturn);
if ($array[21] == 'OK') {
    //$SDTE = $array[0];
    $I1V  = $array[1];
    settype($I1V, 'float');
    $I1A = $array[2];
    settype($I1A, 'float');
    $I1P = $array[3];
    settype($I1P, 'float');
    $I2V = $array[4];
    settype($I2V, 'float');
    $I2A = $array[5];
    settype($I2A, 'float');
    $I2P = $array[6];
    settype($I2P, 'float');
    $G1V = $array[7];
    settype($GV, 'float');
    $G1A = $array[8];
    settype($GA, 'float');
    $G1P = $array[9];
    settype($GP, 'float');
    $FRQ = $array[10];
    settype($FRQ, 'float');
    $EFF = $array[11];
    settype($EFF, 'float');
    $INVT = $array[12];
    settype($INVT, 'float');
    $BOOT = $array[13];
    settype($BOOT, 'float');
    $KWHT = $array[19];
    settype($KWHT, 'float');
    $RET = 'OK';
} else {
    $RET = '';
}
?>

