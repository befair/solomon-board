<?php
if(!defined('checkaccess')){die('Direct access not permitted');}
// Info file
// $CMD_INFO = '';

// Sync inverter
// $CMD_SYNC = '';
?>
