<?php
if (!defined('checkaccess')) {
    die('Direct access not permitted');
}
$CMD_RETURN = ''; // Always initialize the return string, it should always be named $CMD_RETURN to allow 'Communication Error' test

// Omnik.php is a program for reading the parameters out via RS422 of Omnik inverters.
// by Gino Rosi
$dataarray = array();

$a = exec("python /srv/http/123solar/scripts/protocols/p1.py");
$dataarray = preg_split('/[[:space:]]+/', $a);

$I1V = $dataarray[1];
$I1A = $dataarray[2];
$I1P = $I1V * $I1A;
$I2V = 0;
$I2A = 0;
$I2P = 0;
$FRQ = $dataarray[5];
$G1V = $dataarray[4];
$G1A = $dataarray[3];
$G1P = $dataarray[6];
$EFF = ($G1P/$I1P)*100;
$INVT = $dataarray[0];
$BOOT = 0;
$KWHT = $dataarray[7];

if ($FRQ > 0) {
      $RET = 'OK';
}

?>
