<?php
if(!defined('checkaccess')){die('Direct access not permitted');}
$CMD_INFO = "rklogger 11 ${'ADR'.$invt_num} 2 4 8";
?>
