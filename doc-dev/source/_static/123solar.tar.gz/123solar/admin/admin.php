<?php
if (!isset($_SERVER['PHP_AUTH_USER'])) {
    header("Location: ../");
    exit;
}
include('../scripts/version.php');
$url = 'http://123solar.org/latest_version.php';
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>123Solar Administration</title>
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<link rel="stylesheet" href="../styles/default/css/style.css" type="text/css">
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/jquery-ui.min.js"></script>
<script type='text/javascript'>
$(document).ready(function() 
{
var vers='<?php
echo $VERSION;
?>'; 

$.ajax({
    url : '<?php
echo $url;
?>',
    dataType: 'json',
    type: 'GET',
    success: function(response){
	json =eval(response);
	lastvers =json['LASTVERSION'];
	
	if (vers!=lastvers) {
	document.getElementById('status').src = '../images/24/sign-warning.png';
	document.getElementById('msg').innerHTML = '<img src=\'../styles/default/images/sqe.gif\'><a href=\'update.php\'>Update</a>';
	} else {
	document.getElementById('status').src = '../images/24/sign-check.png';
	document.getElementById('msg').innerHTML = '';
	}
    },
    error: function(){
	document.getElementById('status').src = '../images/24/sign-question.png';
        document.getElementById('msg').innerHTML = '';
    },
    timeout: 3000
});

})
</script>
<link rel="stylesheet" href="../js/jqueryuicss/jquery-ui.css" type="text/css">
</head>
<body>
<table width="95%" height="80%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr bgcolor="#FFFFFF" height="80"> 
  <td class="cadretopleft" width="128"><img src="../styles/default/images/sun12880.png" width="128" height="80" alt="123Solar"></td>
  <td class="cadretop" align="center"><b>123Solar Administration</font></td>
  <td class="cadretopright" width="128" align="right"></td>
  </tr>
  <tr bgcolor="#CCCC66">
<td COLSPAN="3" class="cadre" height="10">
&nbsp;
</td></tr>  
<tr valign="top"> 
    <td COLSPAN="3" class="cadrebot" bgcolor="#d3dae2">
<!-- #BeginEditable "mainbox" -->
<br>
<div align=center><b>Welcome <?php
echo $_SERVER["PHP_AUTH_USER"];
?></b></div>
<hr>
<br>&nbsp;
<div align=center><span id='messageSpan'></span></div>
<?php
define('checkaccess', TRUE);

$err_cfgmain = false;
$err_cfginvt = false;
$err_cfgpvo  = false;
$cfgver      = 0;
include('../config/config_main.php');
if ($cfgver < 1428558425 || !isset($cfgver)) {
    $err_cfgmain = true;
}
for ($i = 1; $i <= $NUMINV; $i++) {
    $cfgver = 0;
    include("../config/config_invt" . $i . ".php");
    if ($cfgver < 1502278988 || !isset($cfgver)) {
        $err_cfginvt = true;
    }
}
$cfgver = 0;
include('../config/config_pvoutput.php');
if ($cfgver < 1451373026 || !isset($cfgver)) {
    $err_cfgpvo = true;
}
include('../config/memory.php');
date_default_timezone_set($DTZ);
$SCRDIR = dirname(__FILE__);

if (!empty($_GET['startstop'])) {
    $startstop = $_GET['startstop'];
} else {
    $startstop = null;
}

if ($startstop == 'start' || $startstop == 'stop') {
    $now = date($DATEFORMAT . ' H:i:s');
    if (file_exists('../scripts/123solar.pid')) {
        $pid  = (int) file_get_contents('../scripts/123solar.pid');
        $pidg = posix_getpgid($pid); //id group
        if (!$pidg) {
            $pid = null;
            unlink('../scripts/123solar.pid');
        }
    } else {
        $pid = null;
    }
    if ($startstop == 'start') {
        if (is_null($pid)) {
            if ($DEBUG) {
                $myFile     = dirname($SCRDIR) . '/data/123solar.err';
                $command    = 'php ../scripts/123solar.php' . ' >> ../data/123solar.err 2>&1 & echo $!; ';
                $pid        = exec($command);
                $stringData = "$now\tStarting 123Solar debug ($pid)\n\n";
                if (!file_put_contents('../scripts/123solar.pid', $pid)) {
                    $stringData .= "\n\nCan't write scripts/123solar.pid, you might need to restart php\n\n";
					exec('pkill -f 123solar.php');
                }
                file_put_contents($myFile, $stringData, FILE_APPEND);
            } else {
                $command = 'php ../scripts/123solar.php' . ' > /dev/null 2>&1 & echo $!;';
                $pid     = exec($command);
                file_put_contents('../scripts/123solar.pid', $pid);
            }
            for ($i = 1; $i <= $NUMINV; $i++) {
                include('../config/config_invt' . $i . '.php');
				if ($DEBUG) {
                $stringData = "#* $now\tStarting 123Solar debug ($pid)\n\n";
				} else {
				$stringData = "#* $now\tStarting 123Solar ($pid)\n\n";	
				}
                if (${'SKIPMONITORING' . $i}) {
                    $stringData .= "#$i $now\tInverter down for maintenance\n\n";
                }
                $DATADIR = dirname($SCRDIR) . "/data/invt$i";
                $stringData .= file_get_contents($DATADIR . '/infos/events.txt');
                file_put_contents($DATADIR . '/infos/events.txt', $stringData);
            }
        }
    }
    if ($startstop == 'stop') {
        if (!is_null($pid)) {
            $command = exec("kill -9 $pid > /dev/null 2>&1 &");
            unlink('../scripts/123solar.pid');
            if ($DEBUG) {
                $stringData = "$now\tStopping 123Solar ($pid)\n\n";
                $myFile     = dirname($SCRDIR) . '/data/123solar.err';
                file_put_contents($myFile, $stringData, FILE_APPEND);
            }
            for ($i = 1; $i <= $NUMINV; $i++) {
                $stringData = "#* $now\tStopping 123Solar ($pid)\n\n";
                $DATADIR    = dirname($SCRDIR) . "/data/invt$i";
                $stringData .= file_get_contents($DATADIR . '/infos/events.txt');
                file_put_contents($DATADIR . '/infos/events.txt', $stringData);
            }
        }
        $pid = null;
        unlink($LIVEMEMORY);
        $data               = file_get_contents($MEMORY);
        $memarray           = json_decode($data, true);
        $memarray['status'] = '123Solar stopped';
        $data               = json_encode($memarray);
        file_put_contents($MEMORY, $data);
    }
    echo "
<script type='text/javascript'>
  document.getElementById('messageSpan').innerHTML = \"...Please wait...\"; 
  setTimeout(function () {
    window.location.href = 'admin.php?startstop=done';
  }, 1000);
</script>
";
}
echo "
<table border=0 align='center' width='80%'>
<tr><td align='left'>";

if ($startstop != 'start' && $startstop != 'stop') {
    echo "<form action='admin.php' method='GET'>";
    if (file_exists('../scripts/123solar.pid')) {
        $pid = file_get_contents('../scripts/123solar.pid');
    } else {
        $pid = null;
    }
    
    if (is_null($pid)) {
        echo "<input type='image' src='../images/off.png' value='' width=121 height=57>
		<input type='hidden' name='startstop' value='start'>";
    } else {
        echo "<input type='image' src='../images/on.png' value='' width=121 height=57 onclick=\"if(!confirm('Stop 123Solar ?')){return false;}\">
		<input type='hidden' name='startstop' value='stop'>";
    }
    if ($err_cfgmain || $err_cfginvt || $err_cfgpvo) {
        echo "<br><img src='../images/24/sign-error.png' width='24' height='24' border='0'>Your config file(s) need(s) to be updated !";
    }
    echo "</form>	
<br><img src='../styles/default/images/sqe.gif'><a href='admin_main.php'>Main configuration</a>";
    if ($err_cfgmain) {
        echo "<img src='../images/24/sign-warning.png' width='24' height='24' border='0'>";
    }
    ;
    echo "<br><br><img src='../styles/default/images/sqe.gif'><a href='admin_invt.php'>Configure your inverter(s)</a>";
    if ($err_cfginvt) {
        echo "<img src='../images/24/sign-warning.png' width='24' height='24' border='0'>";
    }
    ;
    echo "<br><br><img src='../styles/default/images/sqe.gif'><a href='admin_pvo.php'>PVoutput configuration</a> <a href='http://www.pvoutput.org/listteam.jsp?tid=317' target='_blank'><img src='../images/link.png' width=16 height=16 border=0></a>";
    if ($err_cfgpvo) {
        echo "<img src='../images/24/sign-warning.png' width='24' height='24' border='0'>";
    }
    ;
    echo "<br><br><img src='../styles/default/images/sqe.gif'><a href='help.php'>Help and debugger</a>
<br><br><span id='msg'><span>
<br>
<br>
</tr></td>
</table>
<form><div align=center>
<INPUT TYPE='button' onClick=\"location.href='../'\" value='Back'>
</div>
</form>
<hr>
<table border=0 cellspacing=0 cellpadding=0 width='100%' align=center>
<tr valign=top><td>&nbsp;</td>
<td width='33%'>
<div align=center><a href='kiva.html'>123solar is free !</a></div>
</td>
<td width='33%' align=right><a href='update.php'><img src='../images/24/sign-sync.png' id='status' width=24 height=24> $VERSION</a></td>
</tr>
</table>
";
}
?>
<br>
<br>
          <!-- #EndEditable -->
          </td>
          </tr>
</table>
</body>
</html>