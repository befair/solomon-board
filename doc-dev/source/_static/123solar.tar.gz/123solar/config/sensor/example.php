<?php
// $SSR should output a W/m² value

$SSR = 123;
?>
