<?php
// Highest inverter temperature
if ($INVT > $TEMP) {
	$TEMP = $INVT;
}	
?>
