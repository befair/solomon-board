<?php
if(!defined('checkaccess')){die('Direct access not permitted');}

// ### PVOUTPUT.org 
$NUMPVO=0;

$cfgver=1451373026;	
?>
