<?php
if(!defined('checkaccess')){die('Direct access not permitted');}
// ### GENERAL
$NUMINV=1;
$DISTRO='arch_ARM';
$DEBUG=false;

// ### LOCALIZATION
$DTZ='Europe/Brussels';
$LATITUDE=50.609;
$LONGITUDE=4.635;
$DATEFORMAT='d/m/Y';
$DPOINT=',';
$THSEP='.';

// ### WEB PAGE
$TITLE='123Solar logger';
$SUBTITLE='« The sun is new each day »';
 
// ### CLEANUP
$KEEPDDAYS=730;
$AMOUNTLOG=2500;

$cfgver=1428558425;
?>
