          <!-- #EndEditable -->
          </td>
          </tr>
<tr valign="top">
<td><?php include("styles/selectstyles.php");?></td>
<td><p align="center"><br><font size="-4"><a href="http://www.123solar.org">Powered by 123Solar</a></font></p></td>
<td align="right"><font size="-2"><a href='admin/'>admin</a></font></td>
</tr>
</table>
</body>
</html>
