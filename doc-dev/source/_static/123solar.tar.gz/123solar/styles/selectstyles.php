<?php // Styles selection
$currentFile = $_SERVER["PHP_SELF"];
$parts = Explode('/', $currentFile);
$currentFile=$parts[count($parts) - 1];

$output = scandir('styles/');
sort($output);
$xstyle=count($output);
$j=0;
for ($i=0;$i<$xstyle;$i++){ 
  if ($output[$i]!='.' && $output[$i]!='..' && !preg_match('/\.php$/i', $output[$i]) ) {
  $style[$j]=$output[$i];
  $j++;
  }
}
sort($style);
$xstyle=count($style); 
  
echo"<form method=\"POST\" action=\"$currentFile\">
<font size=\"-2\">Style :</font>
<select name='user_style' onchange='this.form.submit()' style=\"font-size:0.8em\">";
for ($i=0;$i<$xstyle;$i++){ 
    if ($user_style==$style[$i]) {
      echo "<option SELECTED>";
    } else {
      echo "<option>";
    }
echo "$style[$i]</option>";
}
echo"</select></form>";
?>
