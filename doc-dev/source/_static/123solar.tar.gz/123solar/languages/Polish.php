<?php
// The file must be saved in the proper encoding format (charset UTF-8).
// ### MENU
$lgINVT='Invertor';
$lgMINDEX='Podsumowanie';
$lgMDETAILED='Szczeg�lowy';
$lgMPRODUCTION='Wyprodukowano';
$lgMCOMPARISON='Por�wnanie';
$lgMINFO='Informacja';

// ### FRONT PAGE
$lgPOWERPLANT='Elektrownia';
$lgTODAYTITLE='Wykres dzisiejszej produkcji';
$lgYESTERDAYTITLE='Wczorajsza produkcja';
$lgLASTPRODTITLE='Produkcja poprzednia';
$lgDAYS='Dni';
$lgLASTPRODSUBTITLE='Kliknij na kolumne - szczeg�ly dziennej produkcji';
$lgAVGP='Srednia wydajnosc';
$lgENERGY='Energia';
$lgSUNRISE='Wsch�d slonca o';
$lgTRANSIT='Poludnie o';
$lgSUNSET='Zach�d slonca o';
$lgPMAX='Dzisiejsze maksimum';
$lgTOTAL='Og�lem';

// ### DASHBOARD
$lgDASHBOARD='Tablica wskaznik�w';
$lgAWCHK='Alarm/Ostrzezenie/Kontrola stanu';
$lgPPEAK='Maksymalna wydajnosc';
$lgPPEAKOTD='Dzisiaj';

// ### DETAILED
$lgCHOOSEDATE='Wybierz date';
$lgPOWERAVG='Moc (srednia)';
$lgPOWERAVGINFO='Srednia moc jest z dw�ch pr�bek - bardziej wiarygodne w pochmurnej pogodzie ';
$lgPROD='Produkcja';
$lgARRAY='Wejscie';
$lgPOWER='Moc';
$lgVOLTAGE='Napiecie';
$lgCURRENT='Prad';
$lgPERF='Wydajnosc';
$lgEFF='Efektywnosc';
$lgGRID='Siec';
$lgPHASE='Faza';
$lgFREQ='Czestotliwosc';
$lgINVERTER='Inverter';
$lgBOOSTER='Booster (DC/DC)';
$lgTEMP='Temperatura';
$lgSENSOR='Sensor';

//DETAILED PAGE
$lgDETAILEDOFTITLE='Szczeg�ly z dnia';
$lgDETAILSUBTITLE='Zaznaczyc obszar, aby powiekszyc. Kliknij na legendzie, aby ukryc lub wyswietlic krzywa danych';
$lgDPOWERAVG='Srednia wydajnosc';
$lgDPOWER='Wejscie';
$lgDVOLTAGE='Napiecie';
$lgDCURRENT='Prad';
$lgDPERF='Wydajnosc';
$lgDEFF='Efektywnosc';
$lgDPHASE='Faza';
$lgDFREQ='Czestotliwosc';
$lgDINVERTER='Inverter';
$lgDBOOSTER='Booster (DC/DC)';
$lgDTEMP='Temperatura';

//Buttons
$lgOK='OK';
$lgBACK='Wr�c';

// ### PRODUCTION
$lgPRODTITLE='Produkcja z';
$lgPRODSUBTITLE='Kliknij na kolumnie, aby wyswietlic miesiac dziennej produkcji';
$lgPRODSUBTITLE2='Kliknij, aby wr�cic do miesiecznej ilosci wyprodukowanej energii';
$lgSHOWEXPECTED='Pokaz przewidywana produkcje';
$lgPRODTOOLTIP='Kliknij dla szczeg�l�w';
$lgPRODTOOLTIP2='Wr�c';
$lgPRODTOOLTIPEXPECTED='przewidywane';
$lgALL='Wszystko';

// ### COMPARISON
$lgCOMPARETITLE='Por�wnanie produkcji za okres';
$lgCOMPARESUBTITLE='Wskazniki skutecznosci oblicza sie w odniesieniu do wyjscia por�wnawczego';
$lgWITH='z';
$lgCOMPAREDWITH='Por�wnanie z miesiacem';
$lgPRODCUM='Calkowita produkcja';
$lgGLOBPERF='Wydajnosc';

// ### DATES
$lgSMONTH[1]='Styczen';
$lgSMONTH[2]='Luty';
$lgSMONTH[3]='Marzec';
$lgSMONTH[4]='Kwiecien';
$lgSMONTH[5]='Maj';
$lgSMONTH[6]='Czerwiec';
$lgSMONTH[7]='Lipiec';
$lgSMONTH[8]='Sierpien';
$lgSMONTH[9]='Wrzesien';
$lgSMONTH[10]='Pazdziernik';
$lgSMONTH[11]='Listopad';
$lgSMONTH[12]='Grudzien';
$lgSMONTH[13]='Rok';
$lgMONTH[1]='Styczen';
$lgMONTH[2]='Luty';
$lgMONTH[3]='Marzec';
$lgMONTH[4]='Kwiecien';
$lgMONTH[5]='Maj';
$lgMONTH[6]='Czerwiec';
$lgSMONTH[7]='Lipiec';
$lgSMONTH[8]='Sierpien';
$lgSMONTH[9]='Wrzesien';
$lgSMONTH[10]='Pazdziernik';
$lgSMONTH[11]='Listopad';
$lgSMONTH[12]='Grudzien';
$lgSMONTH[13]='Rok';
$lgMONTH[1]='Styczen';
$lgMONTH[2]='Luty';
$lgMONTH[3]='Marzec';
$lgMONTH[4]='Kwiecien';
$lgMONTH[5]='Maj';
$lgMONTH[6]='Czerwiec';
$lgMONTH[7]='Lipiec';
$lgMONTH[8]='Sierpien';
$lgMONTH[9]='Wrzesien';
$lgMONTH[10]='Pazdziernik';
$lgMONTH[11]='Listopad';
$lgMONTH[12]='Grudzien';
$lgMONTH[13]='Rok';
$lgWEEKD[1]='Niedziela';
$lgWEEKD[2]='Poniedzialek';
$lgWEEKD[3]='Wtorek';
$lgWEEKD[4]='Sroda';
$lgWEEKD[5]='Czwartek';
$lgWEEKD[6]='Piatek';
$lgWEEKD[7]='Sobota';

// ###INFO
$lgPLANTINFO='Informacje';
$lgLOCATION='Lokalizacja';
$lgPLANTPOWER='Zainstalowana moc';
$lgCOUNTER='Wytworzona energia';
$lgTOTALPROD='Og�lem wytworzono';
$lgECOLOGICALINFO='Ekologiczne informacje';
$lgECOLOGICALINFOB='Ilosc CO2 w por�wnaniu do turbiny gazowej (456 kg CO2 na 1 MWh wyprodukowanej energii)';
$lgINVERTERINFO='Informacje o falowniku';
$lgINVERTERINFOB='Informacje sa aktualizowane co 60 min (Ostatnia zmiana ';
$lgLOGGERINFO='Informacje o urzadzeniu';
$lgEVENTS='Logi';
?>